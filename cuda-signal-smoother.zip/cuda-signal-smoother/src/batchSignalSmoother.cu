/*
 * batchSignalSmoother.cu
 *
 * GPU-accelerated Gaussian smoothing across a large batch of 1-D signals.
 * Each signal is stored as a flat array of float32 values in a binary file.
 *
 * Kernel layout
 * -------------
 *   gridDim.x  = ceil(signalLen / blockDim.x)   (covers samples)
 *   gridDim.y  = numSignals                       (one row per signal)
 *   blockDim.x = 256
 *
 * Every thread smooths exactly one output sample using a Gaussian window
 * whose coefficients live in __constant__ memory.
 */

#include <cuda_runtime.h>
#include <dirent.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

/* ── tuneable constants ─────────────────────────────────────────────────── */
#define KERNEL_RADIUS 12          /* half-width of the Gaussian window        */
#define KERNEL_SIZE   (2 * KERNEL_RADIUS + 1)
#define GAUSS_SIGMA   4.0f        /* std-dev in samples                       */
#define BLOCK_SIZE    256         /* threads per block along the sample axis   */
#define MAX_SIGNALS   1024        /* upper bound for static host arrays        */
#define MAX_PATH_LEN  512

/* ── Gaussian weights in fast constant memory ───────────────────────────── */
__constant__ float d_gaussKernel[KERNEL_SIZE];

/* ══════════════════════════════════════════════════════════════════════════
 *  CUDA KERNEL
 * ══════════════════════════════════════════════════════════════════════════ */
__global__ void gaussianSmoothKernel(
        const float * __restrict__ input,
        float       * __restrict__ output,
        int signalLen,
        int numSignals)
{
    const int sampleIdx = (int)(blockIdx.x * blockDim.x + threadIdx.x);
    const int signalIdx = (int)blockIdx.y;

    if (signalIdx >= numSignals || sampleIdx >= signalLen) return;

    const float *in  = input  + (long long)signalIdx * signalLen;
    float       *out = output + (long long)signalIdx * signalLen;

    float acc  = 0.0f;
    float wsum = 0.0f;

    #pragma unroll 4
    for (int k = -KERNEL_RADIUS; k <= KERNEL_RADIUS; ++k) {
        int idx = sampleIdx + k;
        /* mirror-pad at boundaries */
        if (idx < 0)          idx = -idx;
        if (idx >= signalLen) idx = 2 * signalLen - 2 - idx;
        float w = d_gaussKernel[k + KERNEL_RADIUS];
        acc  += w * in[idx];
        wsum += w;
    }
    out[sampleIdx] = acc / wsum;
}

/* ── helpers ────────────────────────────────────────────────────────────── */
#define CUDA_CHECK(call)                                                       \
    do {                                                                       \
        cudaError_t _e = (call);                                               \
        if (_e != cudaSuccess) {                                               \
            fprintf(stderr, "CUDA error %s:%d — %s\n",                        \
                    __FILE__, __LINE__, cudaGetErrorString(_e));               \
            exit(EXIT_FAILURE);                                                \
        }                                                                      \
    } while (0)

static int cmp_str(const void *a, const void *b)
{
    return strcmp(*(const char **)a, *(const char **)b);
}

/* Build a sorted list of *.bin files in dir_path.
   Returns number of files found; fills paths[]. */
static int collect_bin_files(const char *dir_path,
                              char paths[][MAX_PATH_LEN],
                              int  max_files)
{
    DIR *d = opendir(dir_path);
    if (!d) { perror("opendir"); exit(EXIT_FAILURE); }

    /* collect basenames first for sorting */
    static const char *names[MAX_SIGNALS];
    static char        name_buf[MAX_SIGNALS][256];
    int n = 0;

    struct dirent *ent;
    while ((ent = readdir(d)) != NULL && n < max_files) {
        size_t len = strlen(ent->d_name);
        if (len > 4 && strcmp(ent->d_name + len - 4, ".bin") == 0) {
            strncpy(name_buf[n], ent->d_name, 255);
            names[n] = name_buf[n];
            ++n;
        }
    }
    closedir(d);

    qsort(names, (size_t)n, sizeof(char *), cmp_str);

    for (int i = 0; i < n; ++i)
        snprintf(paths[i], MAX_PATH_LEN, "%s/%s", dir_path, names[i]);

    return n;
}

/* Read a flat float32 binary file; returns element count. */
static int read_bin(const char *path, float **buf)
{
    FILE *f = fopen(path, "rb");
    if (!f) { perror(path); exit(EXIT_FAILURE); }
    fseek(f, 0, SEEK_END);
    long sz = ftell(f);
    rewind(f);
    int n = (int)(sz / sizeof(float));
    *buf = (float *)malloc(sz);
    if (!*buf) { fputs("malloc failed\n", stderr); exit(EXIT_FAILURE); }
    fread(*buf, sizeof(float), (size_t)n, f);
    fclose(f);
    return n;
}

/* Write a flat float32 binary file. */
static void write_bin(const char *path, const float *buf, int n)
{
    FILE *f = fopen(path, "wb");
    if (!f) { perror(path); exit(EXIT_FAILURE); }
    fwrite(buf, sizeof(float), (size_t)n, f);
    fclose(f);
}

/* ══════════════════════════════════════════════════════════════════════════
 *  MAIN
 * ══════════════════════════════════════════════════════════════════════════ */
int main(int argc, char *argv[])
{
    if (argc != 3) {
        fprintf(stderr, "Usage: %s <input_dir> <output_dir>\n", argv[0]);
        return EXIT_FAILURE;
    }
    const char *in_dir  = argv[1];
    const char *out_dir = argv[2];

    /* ── 1. discover input files ────────────────────────────────────────── */
    static char in_paths[MAX_SIGNALS][MAX_PATH_LEN];
    int num_signals = collect_bin_files(in_dir, in_paths, MAX_SIGNALS);
    if (num_signals == 0) {
        fputs("No .bin files found in input directory.\n", stderr);
        return EXIT_FAILURE;
    }
    printf("Found %d signal files in %s\n", num_signals, in_dir);

    /* ── 2. load all signals; verify uniform length ─────────────────────── */
    static float *h_signals[MAX_SIGNALS];
    int signal_len = 0;

    for (int i = 0; i < num_signals; ++i) {
        int n = read_bin(in_paths[i], &h_signals[i]);
        if (i == 0) { signal_len = n; }
        else if (n != signal_len) {
            fprintf(stderr, "Signal length mismatch at file %d (%d vs %d)\n",
                    i, n, signal_len);
            return EXIT_FAILURE;
        }
    }
    printf("Signal length : %d samples\n", signal_len);
    long long total_samples = (long long)num_signals * signal_len;
    printf("Total samples : %lld\n", total_samples);

    /* ── 3. build Gaussian kernel on host; upload to constant memory ─────── */
    float h_kernel[KERNEL_SIZE];
    float ksum = 0.0f;
    for (int k = -KERNEL_RADIUS; k <= KERNEL_RADIUS; ++k) {
        float v = expf(-(float)(k * k) / (2.0f * GAUSS_SIGMA * GAUSS_SIGMA));
        h_kernel[k + KERNEL_RADIUS] = v;
        ksum += v;
    }
    /* normalise (kernel is re-normalised per sample anyway, but keep clean) */
    for (int k = 0; k < KERNEL_SIZE; ++k) h_kernel[k] /= ksum;
    CUDA_CHECK(cudaMemcpyToSymbol(d_gaussKernel, h_kernel,
                                  KERNEL_SIZE * sizeof(float)));

    /* ── 4. allocate device buffers ─────────────────────────────────────── */
    size_t batch_bytes = (size_t)num_signals * signal_len * sizeof(float);
    float *d_input, *d_output;
    CUDA_CHECK(cudaMalloc(&d_input,  batch_bytes));
    CUDA_CHECK(cudaMalloc(&d_output, batch_bytes));

    /* ── 5. copy host → device (interleave all signals into one flat buffer) */
    float *h_batch = (float *)malloc(batch_bytes);
    if (!h_batch) { fputs("malloc failed\n", stderr); return EXIT_FAILURE; }

    for (int i = 0; i < num_signals; ++i)
        memcpy(h_batch + (long long)i * signal_len, h_signals[i],
               (size_t)signal_len * sizeof(float));

    CUDA_CHECK(cudaMemcpy(d_input, h_batch, batch_bytes, cudaMemcpyHostToDevice));

    /* ── 6. launch kernel ───────────────────────────────────────────────── */
    dim3 block(BLOCK_SIZE, 1, 1);
    dim3 grid((unsigned)((signal_len + BLOCK_SIZE - 1) / BLOCK_SIZE),
              (unsigned)num_signals,
              1);

    /* use CUDA events for precise GPU timing */
    cudaEvent_t t_start, t_stop;
    CUDA_CHECK(cudaEventCreate(&t_start));
    CUDA_CHECK(cudaEventCreate(&t_stop));

    CUDA_CHECK(cudaEventRecord(t_start));
    gaussianSmoothKernel<<<grid, block>>>(d_input, d_output,
                                          signal_len, num_signals);
    CUDA_CHECK(cudaEventRecord(t_stop));
    CUDA_CHECK(cudaEventSynchronize(t_stop));

    CUDA_CHECK(cudaGetLastError());

    float elapsed_ms = 0.0f;
    CUDA_CHECK(cudaEventElapsedTime(&elapsed_ms, t_start, t_stop));
    printf("Kernel execution time : %.3f ms\n", elapsed_ms);

    /* ── 7. copy device → host ──────────────────────────────────────────── */
    float *h_out_batch = (float *)malloc(batch_bytes);
    if (!h_out_batch) { fputs("malloc failed\n", stderr); return EXIT_FAILURE; }
    CUDA_CHECK(cudaMemcpy(h_out_batch, d_output, batch_bytes,
                          cudaMemcpyDeviceToHost));

    /* ── 8. write output files ──────────────────────────────────────────── */
    char out_path[MAX_PATH_LEN];
    for (int i = 0; i < num_signals; ++i) {
        snprintf(out_path, sizeof(out_path), "%s/smoothed_%04d.bin", out_dir, i);
        write_bin(out_path, h_out_batch + (long long)i * signal_len, signal_len);
    }
    printf("Wrote %d smoothed signal files to %s\n", num_signals, out_dir);

    /* ── 9. write run log ───────────────────────────────────────────────── */
    snprintf(out_path, sizeof(out_path), "%s/run_log.txt", out_dir);
    FILE *log = fopen(out_path, "w");
    if (!log) { perror("run_log.txt"); return EXIT_FAILURE; }

    time_t now = time(NULL);
    fprintf(log, "=== CUDA Batch Signal Smoother — Run Log ===\n");
    fprintf(log, "Timestamp             : %s", ctime(&now));
    fprintf(log, "Input directory       : %s\n", in_dir);
    fprintf(log, "Output directory      : %s\n", out_dir);
    fprintf(log, "Signals processed     : %d\n", num_signals);
    fprintf(log, "Samples per signal    : %d\n", signal_len);
    fprintf(log, "Total samples         : %lld\n", total_samples);
    fprintf(log, "Gaussian radius       : %d samples\n", KERNEL_RADIUS);
    fprintf(log, "Gaussian sigma        : %.1f samples\n", GAUSS_SIGMA);
    fprintf(log, "GPU kernel time (ms)  : %.3f\n", elapsed_ms);
    fprintf(log, "Throughput (Msamples/s): %.2f\n",
            (double)total_samples / (elapsed_ms * 1e3));
    fclose(log);

    printf("Run log written to %s/run_log.txt\n", out_dir);

    /* ── 10. cleanup ────────────────────────────────────────────────────── */
    cudaFree(d_input);
    cudaFree(d_output);
    free(h_batch);
    free(h_out_batch);
    for (int i = 0; i < num_signals; ++i) free(h_signals[i]);

    return EXIT_SUCCESS;
}
