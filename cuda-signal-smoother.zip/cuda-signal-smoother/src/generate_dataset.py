#!/usr/bin/env python3
"""
generate_dataset.py
-------------------
Generate a batch of synthetic noisy 1-D signals and save each one as a
flat binary file of IEEE-754 float32 values.

Each signal is the sum of:
  • Two or three sine-wave components (random frequency + phase)
  • White Gaussian noise

Usage
-----
    python3 src/generate_dataset.py \
        --output data/input \
        --count  200 \
        --length 1024 \
        --noise  0.25
"""

import argparse
import os
import struct
import sys
import math
import random


def make_signal(length: int, noise_std: float, seed: int) -> list[float]:
    """Return a list of `length` float32 samples."""
    rng = random.Random(seed)

    # 2–3 sine components with random parameters
    num_components = rng.randint(2, 3)
    components = []
    for _ in range(num_components):
        freq  = rng.uniform(0.01, 0.15)   # cycles per sample
        phase = rng.uniform(0.0, 2 * math.pi)
        amp   = rng.uniform(0.4, 1.0)
        components.append((amp, freq, phase))

    signal = []
    for i in range(length):
        value = sum(a * math.sin(2 * math.pi * f * i + p)
                    for a, f, p in components)
        # Box-Muller for Gaussian noise
        u1 = rng.random() or 1e-12
        u2 = rng.random()
        noise = noise_std * math.sqrt(-2.0 * math.log(u1)) * math.cos(2 * math.pi * u2)
        signal.append(value + noise)

    return signal


def save_bin(path: str, samples: list[float]) -> None:
    """Write samples as a flat array of 32-bit floats (little-endian)."""
    with open(path, "wb") as f:
        f.write(struct.pack(f"<{len(samples)}f", *samples))


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Generate synthetic noisy 1-D signal dataset."
    )
    parser.add_argument("--output", required=True,
                        help="Output directory for .bin files")
    parser.add_argument("--count",  type=int, default=200,
                        help="Number of signals to generate (default: 200)")
    parser.add_argument("--length", type=int, default=1024,
                        help="Samples per signal (default: 1024)")
    parser.add_argument("--noise",  type=float, default=0.25,
                        help="White noise standard deviation (default: 0.25)")
    parser.add_argument("--seed",   type=int, default=42,
                        help="Base random seed (default: 42)")
    args = parser.parse_args()

    os.makedirs(args.output, exist_ok=True)

    print(f"Generating {args.count} signals  "
          f"| length={args.length}  noise_std={args.noise}")

    for i in range(args.count):
        sig  = make_signal(args.length, args.noise, seed=args.seed + i)
        path = os.path.join(args.output, f"signal_{i:04d}.bin")
        save_bin(path, sig)

        if (i + 1) % 50 == 0 or i == args.count - 1:
            print(f"  [{i + 1:>4d}/{args.count}] written")

    total_bytes = args.count * args.length * 4
    print(f"Done. {args.count} files, "
          f"{total_bytes / 1024:.1f} KB total in '{args.output}/'")


if __name__ == "__main__":
    main()
